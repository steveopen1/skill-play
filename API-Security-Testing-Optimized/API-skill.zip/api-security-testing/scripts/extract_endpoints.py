#!/usr/bin/env python3
"""Extract endpoints from OpenAPI/Swagger or Postman collection files.

Usage:
    python extract_endpoints.py api.yaml
    python extract_endpoints.py collection.json
"""

from __future__ import annotations

import json
import sys
from pathlib import Path
from typing import Any

try:
    import yaml  # type: ignore
except Exception:  # pragma: no cover
    yaml = None


def load_document(path: Path) -> Any:
    text = path.read_text(encoding="utf-8")
    if path.suffix.lower() in {".yaml", ".yml"}:
        if yaml is None:
            raise RuntimeError("PyYAML is required to parse YAML files")
        return yaml.safe_load(text)
    return json.loads(text)


def from_openapi(doc: dict[str, Any]) -> list[dict[str, str]]:
    endpoints: list[dict[str, str]] = []
    for path_name, path_item in (doc.get("paths") or {}).items():
        if not isinstance(path_item, dict):
            continue
        for method, op in path_item.items():
            if method.lower() not in {"get", "post", "put", "patch", "delete", "head", "options"}:
                continue
            summary = op.get("summary") if isinstance(op, dict) else None
            endpoints.append({"method": method.upper(), "path": path_name, "summary": summary or ""})
    return endpoints


def walk_postman_items(items: list[Any], out: list[dict[str, str]]) -> None:
    for item in items:
        if not isinstance(item, dict):
            continue
        if isinstance(item.get("request"), dict):
            req = item["request"]
            method = str(req.get("method", "GET")).upper()
            url = req.get("url")
            if isinstance(url, dict):
                path = "/" + "/".join(url.get("path") or []) if url.get("path") else str(url.get("raw", ""))
            else:
                path = str(url or "")
            out.append({"method": method, "path": path, "summary": str(item.get("name", ""))})
        children = item.get("item")
        if isinstance(children, list):
            walk_postman_items(children, out)


def from_postman(doc: dict[str, Any]) -> list[dict[str, str]]:
    out: list[dict[str, str]] = []
    walk_postman_items(doc.get("item") or [], out)
    return out


def main() -> int:
    if len(sys.argv) != 2:
        print("Usage: python extract_endpoints.py <document>", file=sys.stderr)
        return 1
    path = Path(sys.argv[1])
    doc = load_document(path)
    if not isinstance(doc, dict):
        raise ValueError("Expected a JSON or YAML object")

    if "paths" in doc:
        endpoints = from_openapi(doc)
    elif "item" in doc:
        endpoints = from_postman(doc)
    else:
        raise ValueError("Unsupported document type: expected OpenAPI/Swagger or Postman collection")

    print(json.dumps({"endpoint_count": len(endpoints), "endpoints": endpoints}, indent=2, ensure_ascii=False))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
