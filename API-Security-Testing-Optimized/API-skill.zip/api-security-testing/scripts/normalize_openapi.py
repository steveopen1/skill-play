#!/usr/bin/env python3
"""Normalize a minimal subset of OpenAPI/Swagger documents into a compact JSON summary.

Usage:
    python normalize_openapi.py openapi.yaml
    python normalize_openapi.py openapi.json > summary.json
"""

from __future__ import annotations

import json
import sys
from pathlib import Path
from typing import Any

try:
    import yaml  # type: ignore
except Exception:  # pragma: no cover
    yaml = None


def load_document(path: Path) -> dict[str, Any]:
    text = path.read_text(encoding="utf-8")
    if path.suffix.lower() in {".yaml", ".yml"}:
        if yaml is None:
            raise RuntimeError("PyYAML is required to parse YAML files")
        data = yaml.safe_load(text)
    else:
        data = json.loads(text)
    if not isinstance(data, dict):
        raise ValueError("OpenAPI document must be a JSON/YAML object")
    return data


def normalize(doc: dict[str, Any]) -> dict[str, Any]:
    servers = []
    for item in doc.get("servers", []) or []:
        if isinstance(item, dict) and isinstance(item.get("url"), str):
            servers.append(item["url"])

    if not servers and isinstance(doc.get("host"), str):
        scheme = "https"
        schemes = doc.get("schemes")
        if isinstance(schemes, list) and schemes:
            scheme = schemes[0]
        base_path = doc.get("basePath", "")
        servers.append(f"{scheme}://{doc['host']}{base_path}")

    auth_schemes = []
    components = doc.get("components") if isinstance(doc.get("components"), dict) else {}
    security_schemes = components.get("securitySchemes") if isinstance(components.get("securitySchemes"), dict) else {}
    for name, value in security_schemes.items():
        if isinstance(value, dict):
            auth_schemes.append({"name": name, "type": value.get("type"), "scheme": value.get("scheme")})

    paths = []
    for path_name, path_item in (doc.get("paths") or {}).items():
        if not isinstance(path_item, dict):
            continue
        for method, op in path_item.items():
            if method.lower() not in {"get", "post", "put", "patch", "delete", "head", "options"}:
                continue
            if not isinstance(op, dict):
                op = {}
            paths.append(
                {
                    "method": method.upper(),
                    "path": path_name,
                    "operationId": op.get("operationId"),
                    "summary": op.get("summary"),
                    "tags": op.get("tags") or [],
                    "security": op.get("security"),
                }
            )

    return {
        "title": (doc.get("info") or {}).get("title") if isinstance(doc.get("info"), dict) else None,
        "version": (doc.get("info") or {}).get("version") if isinstance(doc.get("info"), dict) else None,
        "servers": servers,
        "auth_schemes": auth_schemes,
        "paths": paths,
        "path_count": len(paths),
    }


def main() -> int:
    if len(sys.argv) != 2:
        print("Usage: python normalize_openapi.py <openapi.json|openapi.yaml>", file=sys.stderr)
        return 1
    path = Path(sys.argv[1])
    data = normalize(load_document(path))
    print(json.dumps(data, indent=2, ensure_ascii=False))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
