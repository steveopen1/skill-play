#!/usr/bin/env python3
"""Render a standardized markdown API security report from JSON input.

Usage:
    python render_report.py findings.json > report.md
"""

from __future__ import annotations

import json
import sys
from pathlib import Path
from typing import Any


def load_json(path: Path) -> dict[str, Any]:
    data = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(data, dict):
        raise ValueError("Top-level report data must be a JSON object")
    return data


def bullet_lines(items: list[str]) -> str:
    if not items:
        return "- not provided\n"
    return "".join(f"- {item}\n" for item in items)


def render_finding(index: int, finding: dict[str, Any]) -> str:
    lines = [f"### Finding {index}: {finding.get('title', '[Title]')}"]
    for key in [
        "severity",
        "confidence",
        "affected_asset",
        "description",
        "evidence",
        "reproduction",
        "impact",
        "remediation",
        "retest_notes",
    ]:
        label = key.replace("_", " ").title()
        value = finding.get(key, "not provided")
        lines.append(f"- {label}: {value}")
    lines.append("")
    return "\n".join(lines)


def render(report: dict[str, Any]) -> str:
    scope = report.get("scope", {})
    auth = report.get("authorization_assumptions", {})
    asset = report.get("asset_summary", {})
    matrix = report.get("test_matrix", [])
    findings = report.get("findings", [])
    gaps = report.get("coverage_gaps", {})
    risk = report.get("overall_risk_summary", {})

    md = ["# API Security Assessment Report", ""]
    md += ["## Scope"]
    for k in ["target", "environment", "api_type"]:
        md.append(f"- {k.replace('_', ' ').title()}: {scope.get(k, 'not provided')}")
    md.append(f"- In-scope assets:\n{bullet_lines(scope.get('in_scope_assets', []))}".rstrip())
    md.append(f"- Out-of-scope assets:\n{bullet_lines(scope.get('out_of_scope_assets', []))}".rstrip())
    md.append("")

    md += ["## Authorization assumptions"]
    for k in ["authorization_status", "authentication_method", "active_testing_allowed"]:
        md.append(f"- {k.replace('_', ' ').title()}: {auth.get(k, 'not provided')}")
    md.append(f"- Test accounts / roles provided:\n{bullet_lines(auth.get('test_accounts_or_roles_provided', []))}".rstrip())
    md.append(f"- Key unknowns:\n{bullet_lines(auth.get('key_unknowns', []))}".rstrip())
    md.append("")

    md += ["## Asset summary"]
    for key, label in [("base_urls", "Base URLs"), ("key_endpoints_or_operations", "Key endpoints / operations"), ("sensitive_objects", "Sensitive objects"), ("high_risk_workflows", "High-risk workflows"), ("trust_boundaries", "Trust boundaries")]:
        md.append(f"- {label}:\n{bullet_lines(asset.get(key, []))}".rstrip())
    md.append("")

    md += ["## Test matrix", "| Area | Endpoints / Objects | Why it matters | Priority | Status |", "|------|----------------------|----------------|----------|--------|"]
    for row in matrix:
        md.append(f"| {row.get('area', '')} | {row.get('endpoints_or_objects', '')} | {row.get('why_it_matters', '')} | {row.get('priority', '')} | {row.get('status', '')} |")
    md.append("")

    md += ["## Findings", ""]
    if findings:
        for i, finding in enumerate(findings, 1):
            if isinstance(finding, dict):
                md.append(render_finding(i, finding))
    else:
        md.append("No confirmed findings were provided.\n")

    md += ["## Coverage gaps"]
    for key, label in [("missing_credentials", "Missing credentials"), ("missing_documentation", "Missing documentation"), ("untested_areas", "Untested areas"), ("reasons", "Reasons")]:
        md.append(f"- {label}:\n{bullet_lines(gaps.get(key, []))}".rstrip())
    md.append("")

    md += ["## Overall risk summary"]
    for key, label in [("highest_risk_issue", "Highest risk issue"), ("most_likely_abuse_path", "Most likely abuse path")]:
        md.append(f"- {label}: {risk.get(key, 'not provided')}")
    md.append(f"- Recommended next actions:\n{bullet_lines(risk.get('recommended_next_actions', []))}".rstrip())
    md.append("")

    return "\n".join(md)


def main() -> int:
    if len(sys.argv) != 2:
        print("Usage: python render_report.py <report.json>", file=sys.stderr)
        return 1
    report = load_json(Path(sys.argv[1]))
    print(render(report))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
