# Sample Report Placeholder

This file is a lightweight sample artifact showing the intended report style.
Use `scripts/render_report.py` to generate a full report from structured JSON data.
