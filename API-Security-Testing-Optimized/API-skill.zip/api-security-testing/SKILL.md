---
name: api-security-testing
description: structured api security assessment for authorized targets. use when the user asks to review a rest or graphql api, analyze openapi or swagger files, inspect postman collections, identify likely api vulnerabilities, validate findings, or generate a standardized api security report with evidence, severity, reproduction, remediation, and retest notes.
---

# API Security Testing

Perform structured security assessment for authorized REST and GraphQL APIs.

This skill is for:
- reviewing an API design or implementation from a security perspective
- building a prioritized API security test matrix
- validating likely findings with clear evidence and caveats
- generating a standardized security report

This skill is not for:
- unauthorized targets
- destructive testing by default
- denial-of-service guidance
- persistence, post-exploitation, or general intrusion workflows
- broad web or internal-network penetration testing outside API scope

## Safety boundary

- Only assess targets the user is authorized to test.
- Default to non-destructive analysis and low-risk verification.
- Do not recommend destructive, volumetric, or persistence-oriented actions.
- If scope, authorization, credentials, or environment are unclear, state assumptions explicitly and continue with the safest useful level of analysis.

## Operating principles

- Be structured, not theatrical.
- Prefer reproducible reasoning over broad claims.
- Separate confirmed findings from hypotheses.
- Record coverage gaps instead of pretending the assessment is complete.
- Use the required report structure every time.

## Workflow

### 1. Confirm input and assessment mode

Identify what the user has provided:
- target URL or base URL
- OpenAPI / Swagger
- Postman collection
- GraphQL schema or introspection output
- authentication method
- test accounts or roles
- environment
- scope restrictions
- whether active verification is allowed

Choose one of these modes:
- **document-driven review**: only specs, collections, schemas, or screenshots are available
- **passive target review**: a live target exists, but credentials or active testing permission are limited
- **authorized active assessment**: the user has provided enough authorization and context to validate likely issues

If inputs are incomplete, continue with the best available assessment and clearly list assumptions and gaps.

See `references/intake.md`.

### 2. Build an asset summary

Map the API surface into a compact inventory:
- base URLs
- endpoints or operations
- authentication boundaries
- roles and trust boundaries
- sensitive objects
- admin or internal operations
- bulk, export, import, file, callback, search, and mutation flows
- likely high-value workflows such as user management, billing, tokens, secrets, approvals, and data export

Prefer concise coverage over exhaustive enumeration when the surface is large.

See `references/asset-discovery.md`.

### 3. Build a prioritized test matrix

Create a practical matrix covering:
- authentication
- authorization
- object-level access
- function-level access
- input handling
- sensitive data exposure
- business-flow abuse
- rate limiting
- documentation and debug exposure

Adapt the matrix to the API type:
- use REST-specific guidance when analyzing REST APIs
- use GraphQL-specific guidance when analyzing GraphQL APIs

The matrix should explain what to test, why it matters, and how urgent it is.

Use:
- `references/test-matrix.md`
- `references/rest-guidance.md`
- `references/graphql-guidance.md`

### 4. Validate and classify findings

Only report a finding when there is enough support to explain:
- affected asset
- evidence
- reproduction path
- realistic impact
- confidence level

When evidence is incomplete:
- label the item as a hypothesis, weak signal, or likely issue
- explain exactly what is missing for confirmation

Do not inflate severity from ambiguous behavior alone.

See `references/validation.md`.

### 5. Produce the final report in the required format

Always use the report template in `references/report-template.md`.

Every report must contain:
- Scope
- Authorization assumptions
- Asset summary
- Test matrix
- Findings
- Coverage gaps
- Overall risk summary

Every finding must contain:
- Severity
- Confidence
- Affected asset
- Description
- Evidence
- Reproduction
- Impact
- Remediation
- Retest notes

## Severity calibration

Use consistent severity language:
- critical
- high
- medium
- low
- informational

Prefer conservative calibration when real-world exploitability is uncertain.

## Protocol handling

For REST APIs:
- focus on resource exposure, method handling, object references, admin functions, bulk actions, export/import, and error handling

For GraphQL APIs:
- focus on field-level authorization, nested traversal, resolver boundaries, mutation abuse, introspection exposure, and data over-fetching

## Optional scripts

Use scripts only when they reduce fragile manual work:
- `scripts/normalize_openapi.py`
- `scripts/extract_endpoints.py`
- `scripts/render_report.py`

Do not describe internal engine internals unless the user explicitly asks.
Do not turn the report into a product pitch.
