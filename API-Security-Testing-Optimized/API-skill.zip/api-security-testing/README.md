# API Security Testing

A narrow, structured skill for authorized API security assessment and reporting.

## What this skill does

This skill helps ChatGPT:
- review REST and GraphQL APIs from a security perspective
- analyze OpenAPI / Swagger files, Postman collections, and GraphQL schemas
- build a prioritized test matrix
- validate likely issues conservatively
- produce a standardized report with evidence, severity, reproduction, remediation, and retest notes

## Supported inputs

- base URL or target URL
- OpenAPI / Swagger JSON or YAML
- Postman collection JSON
- GraphQL schema or introspection output
- authentication notes
- roles or test accounts
- environment and scope restrictions

## Output structure

Every final report should include:
- Scope
- Authorization assumptions
- Asset summary
- Test matrix
- Findings
- Coverage gaps
- Overall risk summary

## Safety boundary

- authorized targets only
- non-destructive by default
- no denial-of-service guidance
- no persistence or post-exploitation workflows
- explicit assumptions when scope or credentials are incomplete

## Bundled resources

- `references/intake.md`
- `references/asset-discovery.md`
- `references/test-matrix.md`
- `references/validation.md`
- `references/report-template.md`
- `references/rest-guidance.md`
- `references/graphql-guidance.md`
- `references/severity-model.md`
- `scripts/normalize_openapi.py`
- `scripts/extract_endpoints.py`
- `scripts/render_report.py`
