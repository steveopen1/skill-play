# REST Guidance

Use this file when the API is REST-style or resource-oriented.

## Focus areas

- object identifiers in paths and query strings
- method confusion across the same resource
- alternate versions exposing weaker controls
- bulk read and bulk write operations
- export and import endpoints
- callback URL configuration
- file upload and file retrieval
- verbose errors and debug metadata

## Common risk signals

- `GET /resource/{id}` with predictable IDs
- `PUT` or `PATCH` routes that accept role, tenant, or owner fields
- undocumented admin or support routes
- query parameters affecting filtering, sorting, or joins on sensitive objects
- separate internal and public route families with inconsistent auth
- data export endpoints returning broad records with limited user context

## Recommended grouping

Group related endpoints by object family or workflow rather than listing every route separately.
Examples:
- user administration
- billing and invoices
- file operations
- reporting and exports
- organization or tenant management
