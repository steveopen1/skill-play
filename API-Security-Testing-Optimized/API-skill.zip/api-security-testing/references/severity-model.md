# Severity Model

Use this file to keep severity calibration conservative and consistent.

## Levels

### critical
Use for issues that support direct, high-impact compromise of sensitive data or privileged control with low friction and clear evidence.

### high
Use for confirmed authorization failures, admin-function exposure, or meaningful access to sensitive objects or workflows.

### medium
Use for issues that are real but constrained by prerequisites, partial impact, or narrower exposure.

### low
Use for weak controls, limited leakage, or issues with modest practical impact.

### informational
Use for observations, hygiene issues, or exposure signals that do not independently establish a harmful vulnerability.

## Rules of thumb

- broken object-level access to sensitive customer or tenant data: high
- unauthorized state-changing admin function: high or critical depending on impact
- exposed docs or introspection without confirmed sensitive access: low or informational
- verbose errors without demonstrated exploitability: low
- speculative or incomplete signals: low or informational with lower confidence
