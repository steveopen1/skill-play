# Asset Discovery Guidance

Use this file to convert raw API materials into a compact security-relevant inventory.

## Goal

Identify the parts of the API that matter most for security testing.

## What to capture

### Core surface
- base URL(s)
- versioning scheme
- routes or operations
- methods
- content types
- auth schemes

### Trust boundaries
- public vs authenticated endpoints
- user vs admin operations
- internal vs external APIs
- service-to-service or callback flows
- tenant or organization boundaries

### Sensitive objects
Look for objects such as:
- users
- roles
- teams
- organizations
- invoices
- payments
- orders
- files
- secrets
- API keys
- tokens
- audit logs
- exports
- configuration objects

### High-risk operation patterns
Flag endpoints or mutations related to:
- create/update/delete user
- role assignment
- permission change
- password reset
- token issue or refresh
- export or bulk download
- import or bulk update
- file upload
- webhook registration
- callback URL configuration
- search or filter on sensitive entities
- internal admin dashboards or debug endpoints

## REST hints

Prioritize endpoints containing patterns like:
- `/admin`
- `/internal`
- `/users`
- `/roles`
- `/permissions`
- `/export`
- `/import`
- `/search`
- `/upload`
- `/files`
- `/billing`
- `/settings`
- `/token`
- `/auth`
- `/debug`

Also watch for:
- bulk operations
- object IDs in path or query
- hidden alternate methods on the same resource
- inconsistent versioned endpoints

## GraphQL hints

Prioritize:
- mutations that change roles, permissions, or state
- fields that expose nested object traversal
- admin-only resolvers
- schema introspection exposure
- wide object graphs with sensitive linked data
- connection or pagination patterns that may expand access unexpectedly

## Asset summary format

Prefer concise output like:

- Base URLs:
- API type:
- Auth schemes:
- Roles observed or assumed:
- Sensitive objects:
- High-risk operations:
- Trust boundaries:
- Unknown areas:

## Prioritization rule

When the surface is large, prefer depth on:
1. auth and role changes
2. user and tenant data
3. export/import and bulk actions
4. file and callback flows
5. financial or administrative operations

Do not waste space on low-risk read-only metadata endpoints unless they support a broader abuse path.
