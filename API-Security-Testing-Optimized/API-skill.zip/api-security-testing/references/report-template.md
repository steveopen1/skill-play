# API Security Assessment Report

## Scope
- Target:
- Environment:
- API type:
- In-scope assets:
- Out-of-scope assets:

## Authorization assumptions
- Authorization status:
- Test accounts / roles provided:
- Authentication method:
- Active testing allowed:
- Key unknowns:

## Asset summary
- Base URLs:
- Key endpoints / operations:
- Sensitive objects:
- High-risk workflows:
- Trust boundaries:

## Test matrix
| Area | Endpoints / Objects | Why it matters | Priority | Status |
|------|----------------------|----------------|----------|--------|

## Findings

### Finding 1: [Title]
- Severity:
- Confidence:
- Affected asset:
- Description:
- Evidence:
- Reproduction:
- Impact:
- Remediation:
- Retest notes:

### Finding 2: [Title]
- Severity:
- Confidence:
- Affected asset:
- Description:
- Evidence:
- Reproduction:
- Impact:
- Remediation:
- Retest notes:

## Coverage gaps
- Missing credentials:
- Missing documentation:
- Untested areas:
- Reasons:

## Overall risk summary
- Highest risk issue:
- Most likely abuse path:
- Recommended next actions:

---

## Report rules

- Always include all major sections, even when some fields are `unknown` or `not provided`.
- Separate confirmed findings from likely issues if evidence is incomplete.
- Do not omit Coverage gaps.
- Do not collapse remediation into one generic paragraph.
- Keep each finding self-contained.
- Retest notes should describe how a fix would be verified.

## Example finding

### Finding: Broken object-level access on invoice retrieval
- Severity: high
- Confidence: high
- Affected asset: `GET /api/invoices/{invoiceId}`
- Description: The endpoint appears to return invoice metadata for objects outside the caller's ownership boundary when the path identifier is modified.
- Evidence: Response comparison indicates that changing `invoiceId` returns another customer's invoice number, amount, and status while using the same authenticated session.
- Reproduction:
  1. Authenticate as a standard user.
  2. Request an invoice owned by that user.
  3. Replace the path identifier with another valid invoice identifier.
  4. Observe that the API returns data for the second invoice instead of denying access.
- Impact: A low-privilege user may read other customers' billing information.
- Remediation: Enforce object-level authorization on every invoice lookup and verify ownership at the resource layer, not only in the UI.
- Retest notes: Re-run the same identifier substitution with multiple roles and confirm the API returns an authorization error or sanitized response for non-owned invoices.
