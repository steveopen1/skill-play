# GraphQL Guidance

Use this file when the API is GraphQL.

## Focus areas

- schema introspection exposure
- field-level authorization
- nested traversal across sensitive relationships
- mutation abuse
- resolver boundary inconsistencies
- over-fetching of sensitive fields
- pagination and connection patterns that expand access unexpectedly

## Common risk signals

- admin-only fields accessible in normal queries
- resolvers that trust client-supplied object identifiers without ownership checks
- mutations that allow role, status, or tenant reassignment
- nested queries exposing linked objects outside the caller's boundary
- excessive data returned through broad fragments or convenience fields

## Reporting guidance

When GraphQL behavior is inferred from the schema alone, state that live resolver behavior has not been confirmed.
Differentiate between schema exposure and confirmed data access.
