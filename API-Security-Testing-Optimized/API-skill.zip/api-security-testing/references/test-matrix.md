# Test Matrix Guidance

Use this file to turn an asset summary into a prioritized security test plan.

## Goal

Produce a matrix that explains:
- what to test
- why it matters
- where it applies
- how urgent it is

## Required matrix columns

| Area | Endpoints / Objects | Why it matters | Priority | Status |
|------|----------------------|----------------|----------|--------|

Use:
- priority: critical, high, medium, low
- status: planned, partially assessed, validated, blocked, not enough evidence

## Required test areas

### 1. Authentication
Check:
- missing auth where auth should exist
- weak token or session handling
- refresh or logout inconsistencies
- alternate paths that bypass auth

### 2. Authorization
Check:
- privilege boundaries
- role enforcement
- admin-only functions exposed to lower roles
- tenant or organization isolation

### 3. Object-level access
Check:
- direct object reference abuse
- path, body, or query ID tampering
- nested object access through related resources
- hidden read/write access to another user's or tenant's data

### 4. Function-level access
Check:
- privileged actions exposed to lower roles
- internal or support functions callable from standard roles
- alternate methods or endpoints enabling the same action

### 5. Input handling
Check:
- injection-sensitive parameters
- unsafe search, filter, sort, or query inputs
- file upload handling
- callback or URL-based input
- inconsistent validation across versions or methods

### 6. Sensitive data exposure
Check:
- verbose error messages
- debug routes
- excessive response fields
- token, secret, key, or internal identifier leakage
- over-fetching in GraphQL

### 7. Business-flow abuse
Check:
- approval bypass
- replayable actions
- duplicate execution
- sequencing flaws
- abuse of discount, credit, quota, or state transitions

### 8. Rate limiting and abuse controls
Check:
- brute-force resistance
- enumeration barriers
- high-value action throttling
- per-user vs per-IP vs per-tenant controls

### 9. Documentation and debug exposure
Check:
- exposed Swagger/OpenAPI docs
- GraphQL introspection
- playgrounds and consoles
- internal environment details
- hidden route disclosure

## Prioritization guidance

Usually prioritize in this order:
1. object-level access
2. function-level access
3. authentication
4. sensitive data exposure
5. business-flow abuse
6. input handling
7. docs/debug exposure
8. rate limiting

Raise priority when the affected asset involves:
- user identities
- financial records
- permissions
- secrets
- admin actions
- bulk data access

## Good matrix behavior

The matrix should be short enough to act on.
Avoid listing every endpoint separately when many share the same risk.
Group by object family or workflow when possible.
