# Intake Guidance

Use this file when the available inputs are incomplete, mixed, or ambiguous.

## Goal

Establish the safest useful assessment mode without blocking on missing details.

## Input types

Common inputs:
- base URL
- OpenAPI / Swagger
- Postman collection
- GraphQL schema or introspection
- screenshots or copied endpoint lists
- auth description
- test roles
- environment notes
- prior findings

## Assessment modes

### 1. Document-driven review
Use when the user provides specs, collections, schema files, screenshots, or copied endpoint lists, but no live target access.

What to do:
- extract API surface
- identify trust boundaries
- build a test matrix
- flag likely weaknesses
- avoid claiming validation unless supported by evidence

### 2. Passive target review
Use when a live target exists, but active verification is limited or authorization is uncertain.

What to do:
- summarize known assets
- identify likely high-risk areas
- note what would need to be validated
- keep language careful and assumption-driven

### 3. Authorized active assessment
Use when the user has clearly provided authorized scope and enough context for validation.

What to do:
- build asset summary
- prioritize test matrix
- validate likely findings
- report confirmed issues separately from hypotheses

## Minimum questions to resolve silently when possible

If the user did not provide them, infer or mark unknown:
- target or artifact type
- API type: REST or GraphQL
- auth model
- roles
- environment
- whether active testing is allowed

Do not stop the workflow just because some inputs are missing.
Proceed with the best available mode and list the gaps.

## Assumptions section

Always write assumptions explicitly when any of these are missing:
- credentials
- multiple roles
- production vs staging environment
- rate-limit safety constraints
- authorization scope
- mutation safety

## Good assumption language

Use language like:
- "This assessment is based on the provided OpenAPI document and does not confirm live behavior."
- "No low-privilege and admin test accounts were provided, so authorization findings are prioritized as hypotheses unless evidence is present."
- "Active verification permission was not explicitly stated; destructive and high-volume checks were excluded."

## Common gaps to record

- no authenticated session
- no low-privilege role
- no admin role
- no write-safe test environment
- incomplete API spec
- hidden internal endpoints
- undocumented webhook or callback behavior
- no sample objects or IDs
