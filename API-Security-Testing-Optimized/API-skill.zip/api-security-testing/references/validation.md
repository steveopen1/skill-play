# Validation Guidance

Use this file when deciding whether a likely issue is confirmed, weak, or still hypothetical.

## Goal

Avoid overclaiming. Report what the evidence supports.

## Validation standard

A confirmed finding should usually support:
- a clearly affected asset
- a reproducible request or interaction path
- observable evidence
- a realistic impact statement
- enough context to explain who can exploit it

## Confidence labels

Use:
- high confidence
- medium confidence
- low confidence

### High confidence
Use when:
- behavior was directly observed
- impact is clear
- reproduction is stable

### Medium confidence
Use when:
- evidence is strong but one key confirmation is missing
- behavior strongly suggests a flaw, but the exact boundary is partially inferred

### Low confidence
Use when:
- the signal is plausible but incomplete
- no stable reproduction exists
- the issue depends on assumptions not yet verified

## Do not overclaim from these alone

The following are not enough on their own:
- a 500 response
- a field name that looks sensitive
- a verbose error without impact context
- undocumented endpoints without demonstrated access
- GraphQL introspection alone
- a suspicious parameter without a meaningful behavior change

## Evidence expectations

Good evidence can include:
- request/response deltas
- role-based comparison
- object ownership mismatch
- unauthorized access to real data fields
- ability to change protected state
- stable reproduction steps

## Reproduction expectations

Keep reproduction concise:
1. starting role or auth state
2. target endpoint or operation
3. modified input or action
4. observed result
5. expected secure behavior

## Impact language

Prefer realistic impact statements:
- "A low-privilege user can read another tenant's invoice metadata."
- "A standard user can invoke an admin-only role-assignment function."
- "The API returns excessive internal fields that simplify further abuse."

Avoid inflated wording like:
- "Full compromise" unless the evidence truly supports it
- "Critical" just because an endpoint looks sensitive

## Hypothesis handling

If not confirmed, phrase it like:
- "Likely authorization gap requiring role-based validation"
- "Possible excessive data exposure pending live response verification"
- "Potential weak boundary around bulk export operations"

Always state what evidence is still missing.
